// Module imports
const performance = require('perf_hooks').performance
const Axios = require('axios')
const Cheerio = require('cheerio')
const htmlToText = require('html-to-text')

// File imports

module.exports = {
    // Inputs (pageContent)
    // pageContent -> Html content of page as a string
    // Output (String)
    // A formated string of all the content with html tags cleaned away
    getTextContent: function (pageContent, opts){
        if (opts.separator !== undefined){
            return htmlToText.fromString(pageContent, {
                wordwrap: null,
                format: {
                    lineBreak: function(elem, fn, options){
                        return `${elem} ${opts.separator.toString()}`
                    }
                }
            })
        }

        // If there are no opts
        return htmlToText.fromString(pageContent, {
            wordwrap: null
        })
    },

    getImages: function(pageContent){

    },

    getLinks: function(pageContent){

    }
}