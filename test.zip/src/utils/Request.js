// Module imports
const performance = require('perf_hooks').performance
const Axios = require('axios')
const Cheerio = require('cheerio')

// File imports

module.exports = {
    // Inputs (url)
    // url -> a valid url in the form of a string
    // Output (String || null)
    // Raw html of page as a string
    getContent: async function(url){
        const perfStart = performance.now
        let content = null
        try {
            const response = await Axios.get(url)
            if (response.status === 200){
                content = Cheerio.load(response.data).html().toString()
            }else if (response.status !== 404){
                console.error('Error in Request.js getContent(url):', err.toString());
            }
        }catch {
            // Ignoring errors
        }
        const perfStop = performance.now
        return content
    }
}