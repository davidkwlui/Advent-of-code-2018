// Module imports

// File imports
const Request = require('./utils/Request')

module.exports = {
    getSingle: async function(url, args) {
        // Get the page content
        const pageContent = await Request.getContent(url)
        if (pageContent !== null){
            // Get the page body

            // Run through options and get whatever else is saved

            // Save all the collected content
        }
    }
}