// Module imports
const fs = require('fs')
const expect = require('chai').expect

// File imports
const Scraper = require('../src/utils/Scraper')


describe('Tests for the Scraper.js functions', () => {
    let exampleComContent = ''
    let exampleComContentCleaned = ''
    
    before(() => {
        // Reading the source for example.com 
        exampleComContent = fs.readFileSync('./test/mock-data/Example Domain.html', 'UTF-8').toString()
        // Have to clean the content with regex, reading the file in was adding a \r\n instead of just a \n
        exampleComContentCleaned = fs.readFileSync('./test/mock-data/Example Domain Clean Text.txt', 'UTF-8').toString().replace(/\r\n/g, '\n')
    })

    // getContent(URL) Tests
    it('Should return the cleaned content of the page', (done) => {        
        const pageText = Scraper.getTextContent(exampleComContent)
        expect(pageText).to.equal(exampleComContentCleaned)
        done()
    })

    it('Should return the cleaned content with correct separators', (done) => {
        const pageText1 = Scraper.getTextContent(exampleComContent, {
            separator: '\n\n\n'
        })
        expect(pageText).to.equal(exampleComContentCleaned)
        done()
    })

    it('Should return null if there is no content on the page')

    it('Should return null if the input is not a html string')
})
