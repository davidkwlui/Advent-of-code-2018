// Module imports
const fs = require('fs')
const expect = require('chai').expect

// File imports
const Request = require('../src/utils/Request')


describe('Tests for the Request.js functions', () => {
    let exampleComContent = ''
    
    before(() => {
        // Reading the source for example.com
        exampleComContent = fs.readFileSync('./test/mock-data/Example Domain.html')
    })

    // getContent(URL) Tests
    it('Should return the content of the page', (done) => {
        const testURL = 'http://example.com/'
        Request.getContent(testURL).then((content) => {
            expect(content.toString().toLowerCase()).to.equal(exampleComContent.toString().toLowerCase())
        }).then(done, done)
    })

    it('Should return null if url is not correct', (done) => {
        const testURL = 'Not a valid URL'
        Request.getContent(testURL).then((content) => {
            expect(content).to.equal(null)
        }).then(done, done)
    })

    it('Should return null if page is a 404', (done) => {
        const testURL = 'https://stackoverflow.com/questions/4414led-if-returning-a-promise-en'
        Request.getContent(testURL).then((content) => {
            expect(content).to.equal(null)
        }).then(done, done)
    })
})
