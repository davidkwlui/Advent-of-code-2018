// Modules
const app = require('commander')

// Files
const Scrappy = require('./src/Scrappy')

app.version('0.0.1')

// Scrap a single page
app.command('scrape')
    .usage('[options] <url...>')
    .option('-o, --output <value>', 'Path to output directory')
    .action((url, args) => Scrappy.getSingle(url, args))

// Scrape a page from a list array

// Scrape a page from a file

// Help

// Parse args
app.parse(process.argv)

